#include "Czlowiek.h"

void Czlowiek::Akcja()
{
	/*
	switch (input[1]) {
		case ARROW_UP: {
			cout << "UP";
		}break;
		case ARROW_DOWN: {
			cout << "DOWN";
		}break;
		case ARROW_LEFT:{
			cout << "LEFT";
		}break;
		case ARROW_RIGHT:{
			cout << "RIGHT";
		}break;
	}
	*/
}