#include "Swiat.h"


int main(){

    int szer = 20, wys = 20;

    cout << "wpisz szer i wys\n";
    cin >> szer;
    cin >> wys;

    Swiat *swiat = new Swiat(szer, wys);

    


    return 0;
}
