#pragma once
#include "Roslina.h"
class TrujacaRoslina :public Roslina {
protected:
    void ZabijAtakujacego(Zwierze* atakujacy, DIRECTION dir);

};